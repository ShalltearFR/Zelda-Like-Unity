﻿using UnityEngine;
using E7.Introloop;
using System;

/// <summary>
/// Here's now to make your own kind of singleton player. Put the class itself into that generic.
/// </summary>
public class DemoSubclassPlayer : IntroloopPlayer<DemoSubclassPlayer>
{
	// We now owns the subclass, that means it is possible to pre assign game-specific songs/settings
	// from the `Resources/Introloop/` folder. The singleton will spawn with them assigned.

	public IntroloopAudio assault;
	[Range(0,2f)]
	public float assaultFade;

	[Space]

    public IntroloopAudio compete;
    [Range(0, 2f)]
    public float competeFade;

    /// <summary>
    /// Now you also have a friendly function name tailored for your game.
    /// </summary>
    public void PlayAssault()
    {
        try
        {
            Play(assault, assaultFade);
        }
        catch (ArgumentNullException)
        {
            Debug.LogError("To run this demo, please put DemoSubclassPlayer.prefab from the Samples in your Resources/Introloop so the custom singleton spawns with asset references connected for use. It is not a good practice for plugins to mess with your Resources folder on import/on installing samples, so I have to ask you to do it :)");
        }
	}

	public void PlayCompete()
	{
        try
        {
            Play(compete, assaultFade);
        }
        catch (ArgumentNullException)
        {
            Debug.LogError("To run this demo, please put DemoSubclassPlayer.prefab from the Samples in your Resources/Introloop so the custom singleton spawns with asset references connected for use. It is not a good practice for plugins to mess with your Resources folder on import/on installing samples, so I have to ask you to do it :)");
        }
	}

	/// <summary>
	/// If you do not wish to use a template prefab which already has IntroloopAudio ready, 
	/// you might do it later like this.
	/// </summary>
	public void LateAssign(IntroloopAudio assault, IntroloopAudio compete)
	{
		this.assault = assault;
		this.compete = compete;
	}
}
